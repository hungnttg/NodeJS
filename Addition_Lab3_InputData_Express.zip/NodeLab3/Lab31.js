//Input dữ liệu vào nodejs
let prompt = require('prompt-sync')({sigint:true});//su dung thu vien nhap lieu
let name = prompt("ten ban la gi?");
console.log(`Ban vua nhap ${name}`);
console.log('Thuc hien phep cong');
const so1 = prompt('Nhap so 1=');
const so2 = prompt('Nhap so 2=');
const tong = Number(so1)+Number(so2);
console.log('Tong cua '+so1+' + '+so2+' = '+tong);
