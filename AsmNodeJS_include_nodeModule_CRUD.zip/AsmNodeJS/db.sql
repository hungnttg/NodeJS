create database asmnode;
use asmnode;
create table customer(
    id int(10) unsigned AUTO_INCREMENT Primary key,
    name varchar(100) not null,
    address varchar(100) not null,
    phone varchar(20)
);