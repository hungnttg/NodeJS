//setup express//////
var express = require('express');
var app=express();
app.listen(process.env.PORT||'3000');
//set up handler bar//////
var expressHbs = require('express-handlebars');
app.engine('.hbs',expressHbs());
app.set('view engine','.hbs');
// //////
// app.get('/',function(req,res){
//     res.send("Xin chao cac");
// });
// //// goi trang handlebars
app.get('/handlebars',function(req,res){
    res.render('index');
});
