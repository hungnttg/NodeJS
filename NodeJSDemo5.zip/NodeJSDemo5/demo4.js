var express = require('express');//tham chieu thu vien
var app = express();//tao doi tuong moi
app.listen(process.env.PORT||'3000');//lang nghe o cong 3000
var expressHbs = require('express-handlebars');//tham chieu handlebars, de dung .hbs
app.engine('.hbs',expressHbs());//dinh nghia su dung hbs
app.set('view engine','.hbs');//view la file hbs
///////dieu huong/////
app.get('/index',(req,res)=>{//duong dan /index -> se goi den file index.hbs
    res.render('index');
});

app.get('/tho',(req,res)=>{//duong dan /tho -> se goi den file tho.hbs
    res.render('tho');
});