var express = require('express');//tham chieu thu vien
var multer = require('multer');
var expressHbs = require('express-handlebars');
var app = express();//tao moi doi tuong
//khai bao thong tin upload: cho luu tru, ten file
var storage = multer.diskStorage({
    destination: (req,file,res)=>{res(null,'./upload');},
    filename: (req,file,res)=>{res(null,file.originalname);}
});
//dinh nghia file upload
var upload = multer({storage:storage});
//goi den trang upload
app.get('/upload',(req,res)=>{
    res.render('upload',{layout:false});
});
//thuc hien dua file len thu muc upload
app.post('/upload',upload.single("avatar"),(req,res)=>{
    console.log(req.file);
    res.send("Upload Completed");
});
//su dung express handlerbars de dieu huong
app.listen(process.env.PORT||'3000');
app.engine('.hbs',expressHbs());
app.set('view engine','.hbs');
app.get('/upload',(req,res)=>{
    res.render('index',{layout:false});
});

