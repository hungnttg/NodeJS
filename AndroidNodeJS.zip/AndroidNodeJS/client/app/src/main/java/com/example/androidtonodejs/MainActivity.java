package com.example.androidtonodejs;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    Button btnConnet;
    TextView lblKQ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnConnet = findViewById(R.id.btnConnect);
        lblKQ = findViewById(R.id.lblKQ);
        btnConnet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConnectNodeJS connectNodeJS = new ConnectNodeJS();
                connectNodeJS.execute();//thuc thi ham doInBackground
            }
        });
    }
    //giao tiep qua AsyncTask
    public class ConnectNodeJS extends AsyncTask<Void,Void,String>{
        public static final String SERVER_URL = "http://192.168.40.103:3000";
        String result;
        String dem;

        //thuc hien ket noi va lay du lieu tu server
        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL url = new URL(SERVER_URL);//lay duong link
                HttpURLConnection connection
                        =(HttpURLConnection)url.openConnection();//mo ket noi den server
                //------- bat dau doc du lieu
                InputStreamReader inputStreamReader
                        =new InputStreamReader(connection.getInputStream());
                BufferedReader bufferedReader
                        =new BufferedReader(inputStreamReader);
                StringBuffer stringBuffer
                        =new StringBuffer();
                while ((dem=bufferedReader.readLine())!=null)
                {
                    stringBuffer.append(dem);
                }//---- ket thuc doc du lieu
                result = stringBuffer.toString();//ket qua doc duoc tu server
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }
        //dien ket qua len client

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            //day du lieu len clienr
            lblKQ.setText(result);
        }
    }

}
