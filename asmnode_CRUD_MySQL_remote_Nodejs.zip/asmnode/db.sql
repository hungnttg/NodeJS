create database sp1;
use sp1;
create table customer(
    id int(10) unsigned auto_increment primary key,
    name varchar(100) not null,
    address varchar(100) not null,
    phone varchar(30)
);