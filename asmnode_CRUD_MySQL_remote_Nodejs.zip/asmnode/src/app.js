const express = require('express'),
      path = require('path'),
      morgan = require('morgan'),
      mysql = require('mysql'),
      myConnection = require('express-myconnection');

const app = express();

// importing routes
const customerRoutes = require('./routes/customer');

// settings
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// middlewares

// $servername = "localhost";
// $username = "id10840443_user";
// $password = "12345678Aa@123";
// $dbname = "id10840443_springbootdb";

  // host: 'localhost',
  // user: 'root',
  // password: '',
  // port: 3306,
  // database: 'mma'

  // host: 'localhost',
  // user: 'id10840443_user',
  // password: '12345678Aa@123',
  // port: 3306,
  // database: 'id10840443_springbootdb'

app.use(morgan('dev'));
app.use(myConnection(mysql, {
  host: '145.14.144.199',
  user: 'id10840443_user',
  password: '12345678Aa@123',
  port: 3306,
  database: 'id10840443_springbootdb'
}, 'single'));
app.use(express.urlencoded({extended: false}));

// routes
app.use('/', customerRoutes);

// static files
app.use(express.static(path.join(__dirname, 'public')));

// starting the server
app.listen(app.get('port'), () => {
   console.log(`khoi dong server tai ${app.get('port')}`);
});
