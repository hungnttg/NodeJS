//cai thu vien: npm install prompt-sync
const pr = require('prompt-sync')();
const input = pr("Nhap gia tri");
console.log(`Vua nhap ${input}`);
//--------------
console.log("Thuc hien phep tinh");
const so1 = pr("a=");
const so2 = pr("b=");
const tong = Number(so1)+Number(so2);
console.log(`Tong la ${tong}`);