//cai thu vien" npm install express
//npm install body-parser
let express = require('express');
let bodyP = require('body-parser');
let app = express();//tao moi doi tuong express
//su dung body parser
app.use(bodyP.urlencoded({extended: true}));
//doc du lieu post den
app.post('/input',(req,res)=>{
    res.send(`Ban vua gui den: ${req.body.ho}   ${req.body.ten} `);
    console.log(`Ban vua gui den: ${req.body.ho}   ${req.body.ten} `);
});
let port = 8080;
app.listen(port,()=>{
    console.log(`Server dang chay o cong ${port}`);//thong bao ra man hinh
});