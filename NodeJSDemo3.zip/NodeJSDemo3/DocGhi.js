var http = require('http');
var fs = require('fs');
http.createServer((req,res)=>{
    //doc
    fs.readFile('./a.html',(err,data)=>{
        res.writeHead(200,{"Content-Type":"text/html"});
        res.write(data);
        return res.end();
    });
    //ghi
    fs.writeFile("text.txt","ghi ra file moi",(err)=>{
        if(err) console.log(err);
    });
}).listen(8080);