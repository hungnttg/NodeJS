var express = require('express');//khai bao su  dung thu vien
var app = express();//tao moi doi tuong app
app.listen(process.env.PORT||'3000');//lang nghe cong 3000
var expressHbs = require('express-handlebars');//su dung handlebars (template)
app.engine('.hbs',expressHbs());//khoi tao va su dung engine
app.set('view engine','.hbs');//setview

app.get('/handlebars',(req,res)=>{
    res.render('index');
});
app.get('/vidu1',(req,res)=>{
    res.render('vidu1');
});
app.get('/tho',(req,res)=>{
    res.render('tho');
});