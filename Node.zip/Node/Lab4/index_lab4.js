var express = require('express');
var app = express();
app.listen(process.env.PORT || '3000');
var expressHbs = require('express-handlebars');
app.engine('.hbs',expressHbs());
app.set('view engine','.hbs');

app.get('/handlebars',function(req,res){
    res.render('index');
});