var cal = require('./caculator');
var a = 3; 
var b = 6;
console.log("Tong la: "+cal.add(a,b));
console.log("Tru la: "+cal.subtract(a,b));
console.log("Nhan la: "+cal.multyply(a,b));
