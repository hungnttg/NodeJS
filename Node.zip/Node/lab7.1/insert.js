const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://hung1:123456@@cluster0-z2zsz.gcp.mongodb.net/test?retryWrites=true";
const client = new MongoClient(uri, { useNewUrlParser: true });
client.connect(function(err,db) {
  const collection = client.db("test").collection("devices");
  // perform actions on the collection object
  if(err) console.log(err);
  else
  console.log("Connected Complete");
  //phan insert duoc thuc hien o day///////////
  //khai bao db
  var dbo = db.db("nodejs");//ten db da duoc tao trong cac video truoc
  //khai bao du lieu
  var myObj = {name: "Nguyen Viet Hung",Adress: "Ha noi"};
  //khai bao collection
  dbo.collection("nodejs_collection").insertOne(myObj,function(err,res){
      if(err) throw err;
      console.log("insert thanh cong");
      db.close();
  });

  ///////////
  //tim kiem (find)
  var dbo = db.db("mydb");
  dbo.collection("customers").findOne({}, function(err, result) {
    if (err) throw err;
    console.log(result.name);
    db.close();
  });
  ////////////
  //query
  var dbo = db.db("mydb");
  var query = { address: "Park Lane 38" };
  dbo.collection("customers").find(query).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
  ////////
  //sort
  var dbo = db.db("mydb");
  var mysort = { name: 1 };
  dbo.collection("customers").find().sort(mysort).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
  ////////delete
  var dbo = db.db("mydb");
  var myquery = { address: 'Mountain 21' };
  dbo.collection("customers").deleteOne(myquery, function(err, obj) {
    if (err) throw err;
    console.log("1 document deleted");
    db.close();
  });
  ///////
  //update
  var dbo = db.db("mydb");
  var myquery = { address: "Valley 345" };
  var newvalues = { $set: {name: "Mickey", address: "Canyon 123" } };
  dbo.collection("customers").updateOne(myquery, newvalues, function(err, res) {
    if (err) throw err;
    console.log("1 document updated");
    db.close();
  });
  ////////

  client.close();
});