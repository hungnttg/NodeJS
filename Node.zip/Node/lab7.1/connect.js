
const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://hung1:123456@@cluster0-z2zsz.gcp.mongodb.net/test?retryWrites=true";
const client = new MongoClient(uri, { useNewUrlParser: true });
client.connect(function(err,db) {
  const collection = client.db("test").collection("devices");
  // perform actions on the collection object
  if(err) console.log(err);
  else
  console.log("Connected");

  // var dbo = client.db("nodejs");
  // dbo.createCollection("customers", function(err, res) {
  //   if (err) throw err;
  //   console.log("Collection created!");
  //   db.close();
  // });
  var dbo = db.db("nodejs");
  var myobj = { name: "Company Inc", address: "Highway 37" };
  dbo.collection("nodejs_collection").insertOne(myobj, function(err, res) {
    if (err) throw err;
    console.log("1 document inserted");
    db.close();
  });

  client.close();
});



