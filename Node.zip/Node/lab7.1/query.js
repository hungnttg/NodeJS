const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://hung1:123456@@cluster0-z2zsz.gcp.mongodb.net/test?retryWrites=true";
const client = new MongoClient(uri, { useNewUrlParser: true });
client.connect(function(err,db) {
  const collection = client.db("test").collection("devices");
  // perform actions on the collection object
  if(err) console.log(err);
  else
  console.log("Connected Complete");
  
  ////////////
  //query
  var dbo = db.db("mydb");
  var query = { address: "Park Lane 38" };
  dbo.collection("customers").find(query).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
  
   

  client.close();
});