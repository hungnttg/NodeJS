var http = require('http');
var fs = require('fs');
http.createServer(function(req,res){
    // fs.writeFile('sinhvien.txt','Xin chao',function(err){
    //     if(err) console.log(err);
    // })
    // var data = "Nguyen Van A";
    // fs.appendFile('sinhvien.txt',data,'utf8',function(err){
    //     if(err) console.log(err);
    // });
    var data = "Tran Van B";
     fs.appendFileSync('sinhvien.txt',data,'utf8',function(err){
        if(err) console.log(err);
    });
}).listen(8001);