var http = require('http');
var fs = require('fs');


http.createServer(function(req,res){
    fs.writeFile('test.txt','Helloo',function(err){
        if(err) console.log(err);
    });
}).listen(8081);