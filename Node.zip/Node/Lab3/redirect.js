var http = require('http');
var fs = require('fs');
http.createServer(function(req,res){
 //ta thuc hien viec redirect nhu sau:
 if(req.url=='/page-b.html')
 {
     //redirect sang trang page-b.html
     res.writeHead(301,{"Location": "http://"+req.headers['host']+'/page-c.html'});
     return res.end();
 }
 else
 {
    // for other URLs, try responding with the page
         // console.log(req.url)
        fs.readFile(req.url.substring(1),
            function(err, data) { 
                if (err) throw err;
                res.writeHead(200);
                res.write(data.toString('utf8'));
                return res.end();
        });

 }
}).listen(8081);