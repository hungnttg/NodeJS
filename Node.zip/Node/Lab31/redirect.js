//import thu vien
var http = require('http');
var fs = require('fs');//file system
http.createServer(function(req,res){
    //ta dinh nghia cach xu ly o day
    if(req.url=='/a.html')
    {
        res.writeHead(301,{"Location":"http://"+req.headers['host']+"/b.html"});//301 de chuyen trang
        return res.end();
    }
    else
    {
        fs.readFile(req.url.substring(1),function(err,data){
            res.writeHead(200);
            res.write(data.toString('utf8'));
            return res.end();
        });
    }
}).listen(8081);
//req.url.substring(1) tra ve tham so dau tien, nghia la tra ve ten file :)
//bay gio chay thu nhe
//co 2 cach
//cach 1
//cach 2: chay bang debug nhu video truoc da huong dan