var http = require('http');
var fs = require('fs');
http.createServer(function(req,res){
    fs.readFile('a.html',function(err,data){
        res.writeHead(200,{"Content-Type":"text/html"});
        res.write(data);
        return res.end();
    });

    fs.writeFile('chao.txt','Xin chao ban',function(err){
        if(err) console.log(err);
    });
}).listen(8001);