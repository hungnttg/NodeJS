//import thu vien
var http = require('http');
var fs = require('fs');//file system
http.createServer(function(req,res){
    // //ta dinh nghia cach xu ly o day
    // if(req.url=='/a.html')
    // {
    //     res.writeHead(301,{"Location":"http://"+req.headers['host']+"/b.html"});//301 de chuyen trang
    //     return res.end();
    // }
    // else
    // {
    //     fs.readFile(req.url.substring(1),function(err,data){
    //         res.writeHead(200);
    //         res.write(data.toString('utf8'));
    //         return res.end();
    //     });
    // }

    var a="";
     fs.readFile(req.url.substring(1),function(err,data){
                res.writeHead(200,{"Content-Type":"text/html"});
                res.write(data);
                a=data;
                return res.end();
            });
    fs.writeFile('test.txt',"hello",function(err){
        if(err) console.log(err);

    });
}).listen(8082);
