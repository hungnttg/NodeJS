//import thu vien
var http = require('http');
http.createServer(function(req,res){
    res.writeHead(300,{'Content-Type':'text/html'});
    res.end('Xin chao cac ban den voi nodejs');
}).listen(8080);