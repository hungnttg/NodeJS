var exports = module.exports;
exports.add = function(a,b)
{
    return a+b;
};

exports.subtract = function(a,b)
{
    return a-b;
};
exports.multyply = function(a,b)
{
    return a*b;
};