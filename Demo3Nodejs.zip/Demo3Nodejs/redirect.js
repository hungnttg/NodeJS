var http = require('http');//tham chieu thu vien http
var fs = require('fs');
http.createServer((req,res)=>{
    if(req.url=='/pageb.html')//neu goi trang pageb.html
    {
        //chuyen sang trang c
        res.writeHead(301,{"Location":"http://"+req.headers['host']+'/pagec.html'});
        return res.end();
    }
    else
    {
        fs.readFile(req.url.substring(1),function(err,data){
            res.writeHead(200);
            res.write(data.toString('utf8'));
            return res.end();
        });
    }
}).listen(8080);