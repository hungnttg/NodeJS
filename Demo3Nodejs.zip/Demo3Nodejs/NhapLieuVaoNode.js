const prompt = require('prompt-sync')();
const name = prompt("Moi ban nhap lieu");
console.log(`Ban vua nhap ${name}`);
const so1 = prompt("So mot: ");
const so2 = prompt("so 2: ");
const tong = Number(so1)+Number(so2);
console.log('Tong cua '+so1+' + '+so2+' = '+tong);