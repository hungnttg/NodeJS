var http = require('http');
var fs = require('fs');
http.createServer((req,res)=>{
    //1doc file
    fs.readFile('./a.html',(err,data)=>{
        res.writeHead(200,{"Content-Type":"text/html"});
        res.write(data.toString('utf8'));
        return res.end();
    });
    //2ghi file
    fs.writeFile('tes.txt','hello cac ban',(err)=>{
        if(err) console.log(err);
    });
}).listen(8081);