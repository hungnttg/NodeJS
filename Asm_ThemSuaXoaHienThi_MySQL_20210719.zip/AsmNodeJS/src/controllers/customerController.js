const controller ={};
//1.doc du lieu tu CSDL (select)
controller.list = (req,res)=>{
    req.getConnection((err,conn)=>{
        conn.query('select * from customer',(err,customers)=>{
            if(err)
            {
                res.json(err);
            }
            res.render('customers',{data: customers});
        });
    });
};
//2. luu du lieu vao csdl
controller.save = (req,res)=>{
    const data = req.body;
    console.log(req.body);
    req.getConnection((err,connection)=>{
        const query = connection.query('insert into customer set ?',data,(err,customer)=>{
            console.log(customer);
            res.redirect('/');
        });
    });
};
//3. edit
controller.edit = (req,res)=>{
    const {id} = req.params;
    req.getConnection((err,conn)=>{
        conn.query("select * from customer WHERE id=?",[id],(err,rows)=>{
            res.render('customers_edit',{data: rows[0]});
        });
    });
};
//4.update
controller.update = (req,res)=>{
    const {id} = req.params;
    const newCustomer = req.body;
    req.getConnection((err,conn)=>{
        conn.query('update customer set ? where id=?',[newCustomer,id],(err,rows)=>{
            res.redirect('/');
        });
    });
};
//5.delete
controller.delete = (req,res)=>{
    const {id}  = req.params;
    req.getConnection((err,connection)=>{
        connection.query('delete from customer where id=?',[id],(err,rows)=>{
            res.redirect('/');
        })
    });
};
//export
module.exports = controller;